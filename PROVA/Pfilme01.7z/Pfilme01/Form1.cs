﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnExecutar_Click(object sender, EventArgs e, int k)
        {
            double notasfilme1 = 0;
            double notasfilme2 = 0;
            double[,] notas = new double[3, 2];
            string auxiliar = "";
            double media = 0;
            double mediageral = 0;
            int pessoa = 0;
            int filme = 0;
            string saida = "";
            int K=0;


            for (int i = 0; i < 3; i++)
            {
                media = 0;

                for (int j = 0; j < 2; j++)
                {
                    auxiliar = Interaction.InputBox($"Pessoa {pessoa + i + 1} - Filme: {filme + j + 1}");


                    if (!double.TryParse(auxiliar, out notas[i, j]) ||
                        notas[i, j] < 0 || notas[i, j] > 10)
                    {
                        MessageBox.Show("Nota inválida! Digite um número entre 0 e 10.",
                            "Erro", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        j--; 

                    }
                    else
                    {

                        notasfilme1 += notas[i, j];
                        notasfilme2 += notas[i, k];
                        media += (notasfilme1 + notasfilme2);
                        
                    }

                    
                }
                media = media / 2;

                listNota.Items.Add("$Pessoa "; {i + 1}; " Nota filme 1: "; {notasfilme1}; "Notas filme 2: "; {notasfilme2});

            }


        }
            


        
        private void btnLimpar_Click(object sender, EventArgs e)
        {
            listNota.Items.Clear();
        }
    }
}
