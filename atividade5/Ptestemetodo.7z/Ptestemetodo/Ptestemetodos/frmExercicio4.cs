﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptestemetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string input = richTextBox1.Text;
            int contaNum = 0;
            int indice = 0;

            while (indice < input.Length)
            {
                if (char.IsNumber(input[indice]))
                {
                    contaNum++;
                }
                indice++;
            }
            MessageBox.Show("Quantidade de caracteres: " + contaNum);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string input = richTextBox1.Text;
            int contAlfa = 0;


            foreach (char c in input)
            {

                if (Char.IsLetter(c))
                {
                    contAlfa++;
                }
            }

            MessageBox.Show("Quantidade de caracteres alfabéticos: " + contAlfa);
        }

        private void button2_Click(object sender, EventArgs e)
        {

            string input = richTextBox1.Text; 
            int posicao = -1; 

            for (int i = 0; i < input.Length; i++)
            {
                if (char.IsWhiteSpace(input[i]))
                {
                    posicao = i+1; 
                    break;
                }
            }
           
            if (posicao == -1)
                MessageBox.Show("Nenhum espaço em branco encontrado!");
            else
                MessageBox.Show("Primeiro espaço em branco está na posição: " + posicao);

        }
    }
}
