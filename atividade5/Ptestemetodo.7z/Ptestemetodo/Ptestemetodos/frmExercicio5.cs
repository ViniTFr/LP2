﻿using System;
using System.Windows.Forms;

namespace Ptestemetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSortear_Click(object sender, EventArgs e)
        {
            int num1, num2;
            num1 = Convert.ToInt16(txtPalavra1.Text);
            num2 = Convert.ToInt16(txtPalavra2.Text);


            if (num2 <= num1)
            {
                MessageBox.Show("O segundo número deve ser maior que o primeiro!", "Erro");
                txtPalavra2.Focus();
            }
            else
            {
                Random random = new Random();
                int numeroSorteado = random.Next(num1, num2);
                MessageBox.Show(numeroSorteado.ToString());
            }
        }
    }
}
