﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            double A = Convert.ToDouble(txtA.Text);
            double B = Convert.ToDouble(txtB.Text);
            double C = Convert.ToDouble(txtC.Text);

            if (A + B > C && B + C > A && A + C > B)
            {
                if (A == B && B == C)
                {
                    MessageBox.Show("Equilatero");
                }
                else if (A == C || B == C || A == C)
                {
                    MessageBox.Show("Isosceles");
                } else
                    MessageBox.Show("Escaleno");
            }
            else
                MessageBox.Show("Nao e triangulo");
        }

        private void txtA_Validated(object sender, EventArgs e)
        {
            double A;
            if (!double.TryParse(txtA.Text, out A) || A <=0)
            {
                MessageBox.Show("Digite um valor valido e maior que zero");
                txtA.Clear();
                txtA.Focus();
            }
        }

        private void txtB_Validated(object sender, EventArgs e)
        {
            double B;
            if (!double.TryParse(txtB.Text, out B) || B <= 0)
            {
                MessageBox.Show("Digite um valor valido e maior que zero");
                txtB.Clear();
                txtB.Focus();
            }
        }

        private void txtC_Validated(object sender, EventArgs e)
        {
            double C;
            if (!double.TryParse(txtC.Text, out C) || C <= 0)
            {
                MessageBox.Show("Digite um valor valido e maior que zero");
                txtC.Clear();
                txtC.Focus();
            }
        }
    }
}
